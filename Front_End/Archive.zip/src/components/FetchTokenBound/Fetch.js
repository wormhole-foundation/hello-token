import "./Fetch.css";
import { abi } from './abi';
import { create } from 'ipfs-http-client';
import { useEffect, useState } from "react";
import { useConnect, useAccount } from 'wagmi';
import { getPublicClient } from '@wagmi/core';
import WalletConnect from "../WalletConnect/WalletConnect";

import { prepareSendTransaction, sendTransaction } from '@wagmi/core';
import { parseEther } from 'viem';
import { writeContract } from '@wagmi/core';
import { useContractReads } from 'wagmi';
import { infuraProvider } from '@wagmi/core/providers/infura';

function Fetch () {
    //const providesr = new ethers.providers.JsonRpcProvider("https://alpha-rpc.scroll.io/l2");
    
    const Contract_Address = "0x0ee7F43c91Ca54DEEFb58B261A454B9E8b4FEe8B";
    const mint_address = "0x7199D548f1B30EA083Fe668202fd5E621241CC89";
    const { connect, connectors, error, isLoading, pendingConnector, provider } = useConnect()
    const { address, isConnected } = useAccount();
    const publicClient = getPublicClient();
    console.log(publicClient);

    if(isConnected){
        console.log("Provider is: ", provider)
    }

    const [myArray, updateMyArray] = useState([]);

    const [fileUrl, updateFileUrl] = useState('');

    const projectId = '2SHg9nYGwUEpcXJuBTdkDcT2tYV';
    const projectSecret = '6834cfa182ec09eeff6577aca368802e';
    const auth = 'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64');
    const client = create({
    host: 'ipfs.infura.io',
    port: 5001,
    protocol: 'https',
    apiPath: '/api/v0',
    headers: {
        authorization: auth,
    }
    });


    async function onChange(e) {
        const file = e.target.files[0];
        let url;
        try {
            const added = await client.add(file)
            url = `https://scrollbarcelona.infura-ipfs.io/ipfs/${added.path}`
            updateFileUrl(url)
        } 
        catch (error) {
            console.log('Error uploading file: ', error)
        } 
        //console.log("URL", fileUrl);
        mint(url); 
    }



    async function mint(url) {
        
        const { hash } = await writeContract({
            address: Contract_Address,
            abi: abi,
            functionName: 'safeMint',
            args: [mint_address, String(url)],
        });

        console.log("Transaction Hash is: ", hash);
    }


    async function Photogallery () 
    {
    
    }

    return(
        <>
        <div className="mybuttons">
           
            <h2 className="nam"> ETH Barcelona Memories </h2>
        </div>
            
            <div className="mybuttons">
            <WalletConnect/>
                <button className="btn" onClick={Photogallery}>NFT Minted</button>
            </div>



            <button className="mintbutton" onClick={mint}>Mint</button>


            {isConnected==false? <h2 className="h2center">
            Connect wallet and Mint NFT on scroll
            </h2>
            :
            <>
                
                <div className="App">
                <h2 className="h2cen">Upload the NFT on IPFS to mint</h2>
      
                <input className="fileup"
                    type="file"
                    onChange={onChange}
                />
                {
                    fileUrl && (
                    <img src={fileUrl} width="600px" /> 
                    )
                }
                <p>{fileUrl}</p>
                </div>
            </>
            }

            
            


            <div className='nfts_container'>
            { 
                myArray.map((temp) => {
                    return  <div className='sold' key={`${temp}`} >
                        
                        <img className="minted" src={`${temp}`} width="250px" height="250px" alt={`${temp}`} /> 
                </div>    
            }) 
            }
        </div>

        </>
    );
}

export default Fetch;